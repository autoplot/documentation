#!/bin/sh

JAVA=/opt/jdk1.5.0_10/bin/java
JAVA=java

CP=`ls lib/* | xargs | tr ' ' :`:VirboAutoplot.jar

nailgun-0.7.1/ng ng-stats
if [ $? -ne 0 ] ; then
   echo "starting nailgun server"
   $JAVA -cp $CP:nailgun-0.7.1/nailgun-0.7.1.jar:. com.martiansoftware.nailgun.NGServer &
fi
 
nailgun-0.7.1/ng org.virbo.autoplot.AutoPlotMatisse $1

