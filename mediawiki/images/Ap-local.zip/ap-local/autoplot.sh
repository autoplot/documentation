#!/bin/sh

#JAVA=/opt/jdk1.5.0_10/bin/java

JAVA=java

CP=`ls lib/* | xargs | tr ' ' :`:VirboAutoplot.jar:.

echo $JAVA -cp $CP org.virbo.autoplot.AutoPlotMatisse
$JAVA -cp $CP org.virbo.autoplot.AutoPlotMatisse $1

